package com.codingcomrades.CEM_fullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CemFullstackApplicationTests {

	@Test
	void contextLoads() {
	}

}
