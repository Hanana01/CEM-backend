package com.codingcomrades.CEM_fullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CemFullstackApplication {

	public static void main(String[] args) {

		SpringApplication.run(CemFullstackApplication.class, args);
	}

}
